<?php

namespace Unilever\SocialLogin\Model\ResourceModel;

class SocialLogin extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    public function _construct()
    {
        $this->_init('unilever_sociallogin', 'id');
    }
}