<?php

namespace Unilever\SocialLogin\Model\Config\Source;

class Size implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            'normal'  => __('Normal'),
            'compact' => __('Compact')
        ];
    }

}