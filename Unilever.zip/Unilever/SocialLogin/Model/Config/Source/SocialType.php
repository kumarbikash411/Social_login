<?php

namespace Unilever\SocialLogin\Model\Config\Source;

class SocialType implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [

            ['value' => 'googleplus', 'label' =>__('Googleplus')],

        ];
    }

}