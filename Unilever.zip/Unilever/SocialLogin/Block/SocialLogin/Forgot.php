<?php

namespace Unilever\SocialLogin\Block\SocialLogin;

class Forgot extends \Magento\Framework\View\Element\Template
{

}
