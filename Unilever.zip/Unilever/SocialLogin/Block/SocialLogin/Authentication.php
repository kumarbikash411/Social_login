<?php

namespace Unilever\SocialLogin\Block\SocialLogin;

use Magento\Customer\Block\Form\Login;

class Authentication extends Login
{

}
