<?php

namespace Unilever\SocialLogin\Controller\Popup;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Unilever\SocialLogin\Helper\Data as HelperData;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Json\Helper\Data as JsonHelper;

class Login extends Action
{
    protected $helperData;

    protected $accountManagement;

    protected $customerSession;

    protected $jsonHelper;

    public function __construct(
        Context $context,
        HelperData $helperData,
        AccountManagementInterface $accountManagement,
        CustomerSession $customerSession,
        JsonHelper $jsonHelper
    ) {
        parent::__construct($context);
        $this->helperData        = $helperData;
        $this->accountManagement = $accountManagement;
        $this->customerSession   = $customerSession;
        $this->jsonHelper        = $jsonHelper;
    }

    public function execute()
    {
        $username      = $this->getRequest()->getParam('username', false);
        $password      = $this->getRequest()->getParam('password', false);
        $recaptcha_response = $this->getRequest()->getParam('g-recaptcha-response', false);
        $result = [];
        $captchaError = '';
        if ($recaptcha_response) {
            $model = \Magento\Framework\App\ObjectManager::getInstance()->get('Unilever\SocialLogin\Model\Recaptcha');
            $captchaError = $model->verify($recaptcha_response);
        }
        if ( !empty($captchaError) ) {
            $result['error'] = $captchaError;
            $this->getResponse()->setBody($this->jsonHelper->jsonEncode($result));
        } elseif ($username && $password) {

            try {
                $accountManage = $this->accountManagement;
                $customer      = $accountManage->authenticate(
                    $username,
                    $password
                );
                $this->customerSession->setCustomerDataAsLoggedIn($customer);
                $this->customerSession->regenerateId();
            } catch (\Exception $e) {
                $result['error']   = true;
                $result['message'] = $e->getMessage();
            }
            
            if (!isset($result['error'])) {
                $result['success'] = true;
                $result['message'] = __('Login successfully. Please wait ...');
                $result['redirect'] = $this->helperData->getRedirectUrl();
            }
        } else {
            $result['error']   = true;
            $result['message'] = __(
                'Please enter a username and password.');
        }
        
        $this->getResponse()->setBody($this->jsonHelper->jsonEncode($result));
        return;
    }
}
