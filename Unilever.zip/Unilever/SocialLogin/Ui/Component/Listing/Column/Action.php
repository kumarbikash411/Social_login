<?php

namespace Unilever\SocialLogin\Ui\Component\Listing\Column;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;

class Action extends \Unilever\SocialLogin\Ui\Component\Listing\Column\AbstractColumn
{


    protected $helper;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Backend\Helper\Data $helper,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->helper = $helper;
    }


    protected function _prepareItem(array & $item)
    {
        if (isset($item['customer_id'])) {
            $item[$this->getData('name')] = '<a href="'.$this->helper->getUrl('customer/*/edit').'id/'.$item['customer_id'].'" class="view-customer" target="_blank">'.__('View Customer').'</a>';
        }

        return $item;
    }
}
