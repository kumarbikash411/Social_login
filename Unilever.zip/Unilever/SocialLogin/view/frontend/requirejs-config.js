var config = {
    paths: {
    	'sociallogin-photo': 'Unilever_SocialLogin/js/photo',
        'sociallogin': 'Unilever_SocialLogin/js/social-popup'
    },
    shim: {
        'sociallogin': {
            deps: ['jquery']
        },
        'sociallogin-photo': {
            deps: ['jquery']
        }
    }
};